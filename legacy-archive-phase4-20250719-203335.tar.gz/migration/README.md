Ready for agent execution
