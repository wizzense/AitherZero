#!/bin/bash
echo "🚀 AitherZero v1.1.0 - Linux Quick Start"
echo "Cross-Platform Infrastructure Automation with OpenTofu/Terraform"
echo ""
pwsh -File "Start-AitherZero.ps1" $@
