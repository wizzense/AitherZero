#Requires -Version 7.0
<#
.SYNOPSIS
    Validates PowerShell script syntax using AST parser
.DESCRIPTION
    Uses the PowerShell AST parser to validate script syntax without executing the code.
    Useful for pre-commit hooks, CI/CD pipelines, and development workflows.
.PARAMETER FilePath
    Path to the PowerShell script file to validate
.PARAMETER Detailed
    Show detailed AST information including function counts and statistics
.EXAMPLE
    ./0407_Validate-Syntax.ps1 -FilePath ./script.ps1
.EXAMPLE
    Get-ChildItem *.ps1 -Recurse | ForEach-Object { ./0407_Validate-Syntax.ps1 -FilePath $_.FullName }
.EXAMPLE
    seq 0407 -Variables @{FilePath="./domains/utilities/Logging.psm1"; Detailed=$true}
#>

# Script metadata
# Stage: Testing
# Dependencies: 0400
# Description: PowerShell syntax validation using AST parser
# Tags: testing, validation, syntax, ast, quality
param(
    [Parameter(Mandatory)]
    [ValidateScript({ Test-Path $_ -PathType Leaf })]
    [string]$FilePath,

    [switch]$Detailed
)

try {
    $parseErrors = $null
    $tokens = $null
    $ast = [System.Management.Automation.Language.Parser]::ParseFile($FilePath, [ref]$tokens, [ref]$parseErrors)

    if ($parseErrors -and $parseErrors.Count -gt 0) {
        Write-Host "Syntax errors found in $FilePath`:" -ForegroundColor Red
        foreach ($parseError in $parseErrors) {
            Write-Host "  Line $($parseError.Extent.StartLineNumber), Column $($parseError.Extent.StartColumnNumber): $($parseError.Message)" -ForegroundColor Yellow
            if ($Detailed) {
                Write-Host "  Context: $($parseError.Extent.Text)" -ForegroundColor DarkYellow
            }
        }
        exit 1
    } else {
        Write-Host "✓ Script syntax is valid: $FilePath" -ForegroundColor Green

        if ($Detailed -and $ast) {
            Write-Host "`nScript Statistics:" -ForegroundColor Cyan
            $functions = $ast.FindAll({ $arguments[0] -is [System.Management.Automation.Language.FunctionDefinitionAst] }, $true)
            Write-Host "  Functions: $($functions.Count)"

            $commands = $ast.FindAll({ $arguments[0] -is [System.Management.Automation.Language.CommandAst] }, $true)
            Write-Host "  Commands: $($commands.Count)"

            Write-Host "  Total Lines: $($ast.Extent.EndLineNumber)"
            Write-Host "  Tokens: $($tokens.Count)"
        }
        exit 0
    }
} catch {
    Write-Host "Error parsing file: $_" -ForegroundColor Red
    exit 1
}