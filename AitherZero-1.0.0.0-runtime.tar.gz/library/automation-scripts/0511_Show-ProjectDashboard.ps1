#Requires -Version 7.0

<#
.SYNOPSIS
    Display comprehensive project dashboard with logs, tests, and metrics
.DESCRIPTION
    Shows an interactive dashboard with project metrics, test results,
    recent logs, module status, and recent activity.
.NOTES
    Stage: Reporting
    Order: 0511
    Tags: reporting, dashboard, monitoring, metrics
#>

[CmdletBinding(SupportsShouldProcess)]
param(
    [string]$ProjectPath = ($PSScriptRoot | Split-Path -Parent),
    [switch]$ShowLogs,
    [switch]$ShowTests,
    [switch]$ShowMetrics,
    [switch]$ShowAll,
    [int]$LogTailLines = 50,
    [switch]$Follow
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

# Import modules
$loggingModule = Join-Path $ProjectPath "aithercore/utilities/Logging.psm1"
if (Test-Path $loggingModule) {
    Import-Module $loggingModule -Force
}

# Clear screen for dashboard
Clear-Host

function Show-Header {
    # Handle non-interactive environments
    $width = 80  # Default width
    if ($Host.UI.RawUI -and $Host.UI.RawUI.WindowSize) {
        try { $width = $Host.UI.RawUI.WindowSize.Width } catch { }
    }
    $line = "=" * $width

    Write-Host $line -ForegroundColor Cyan
    Write-Host " AitherZero Project Dashboard " -ForegroundColor Cyan
    Write-Host $line -ForegroundColor Cyan
    Write-Host ""
}

function Get-PropertyWithFallback {
    <#
    .SYNOPSIS
        Get property value from object with fallback to alternative property names
    .PARAMETER Object
        The object to get the property from
    .PARAMETER PropertyNames
        Array of property names to try in order
    .PARAMETER DefaultValue
        Default value if no property found (default: 0)
    #>
    param(
        [Parameter(Mandatory)]
        $Object,
        
        [Parameter(Mandatory)]
        [string[]]$PropertyNames,
        
        $DefaultValue = 0
    )
    
    foreach ($propName in $PropertyNames) {
        if ($null -ne $Object.$propName) {
            return $Object.$propName
        }
    }
    return $DefaultValue
}

function Show-ProjectMetrics {
    Write-Host "PROJECT METRICS" -ForegroundColor Yellow
    Write-Host ("-" * 40) -ForegroundColor Gray

    # Get latest report
    $reportPath = Join-Path $ProjectPath "library/tests/reports"
    $latestReport = Get-ChildItem -Path $reportPath -Filter "ProjectReport-*.json" -ErrorAction SilentlyContinue |
        Sort-Object LastWriteTime -Descending | Select-Object -First 1

    if ($latestReport) {
        $report = Get-Content $latestReport.FullName | ConvertFrom-Json

        Write-Host "Total Files: " -NoNewline
        Write-Host "$($report.FileAnalysis.TotalFiles)" -ForegroundColor Green

        Write-Host "Code Files: " -NoNewline
        Write-Host "$($report.Coverage.TotalFiles)" -ForegroundColor Green

        Write-Host "Functions: " -NoNewline
        Write-Host "$($report.Coverage.FunctionCount)" -ForegroundColor Green

        Write-Host "Lines of Code: " -NoNewline
        Write-Host "$($report.Coverage.CodeLines)" -ForegroundColor Green

        Write-Host "Comment Ratio: " -NoNewline
        $commentColor = if ($report.Coverage.CommentRatio -ge 20) { "Green" } elseif ($report.Coverage.CommentRatio -ge 10) { "Yellow" } else { "Red" }
        Write-Host "$($report.Coverage.CommentRatio)%" -ForegroundColor $commentColor

        Write-Host "Documentation: " -NoNewline
        $docColor = if ($report.Documentation.HelpCoverage -ge 80) { "Green" } elseif ($report.Documentation.HelpCoverage -ge 50) { "Yellow" } else { "Red" }
        Write-Host "$($report.Documentation.HelpCoverage)%" -ForegroundColor $docColor
    } else {
        Write-Host "No project report found. Run 0510_Generate-ProjectReport.ps1" -ForegroundColor Red
    }
    Write-Host ""
}

function Show-TestResults {
    Write-Host "TEST RESULTS" -ForegroundColor Yellow
    Write-Host ("-" * 40) -ForegroundColor Gray

    $testResultsPath = Join-Path $ProjectPath "library/tests/results"
    if (-not (Test-Path $testResultsPath)) {
        Write-Host "Test results directory not found" -ForegroundColor Yellow
        Write-Host ""
        return
    }

    $testSummaries = Get-ChildItem -Path $testResultsPath -Filter "*Summary*.json" -ErrorAction SilentlyContinue |
        Sort-Object LastWriteTime -Descending | Select-Object -First 5

    if ($testSummaries) {
        foreach ($summary in $testSummaries) {
            try {
                $data = Get-Content $summary.FullName -Raw | ConvertFrom-Json
                $timestamp = $summary.BaseName -replace '.*-(\d{8}-\d{6}).*', '$1'

                Write-Host "[$timestamp] " -NoNewline -ForegroundColor Gray

                # Support multiple property name variations using helper function
                $failed = Get-PropertyWithFallback -Object $data -PropertyNames @('Failed', 'FailedCount')
                $passed = Get-PropertyWithFallback -Object $data -PropertyNames @('Passed', 'PassedCount')
                $total = Get-PropertyWithFallback -Object $data -PropertyNames @('TotalTests', 'TotalCount') -DefaultValue ($passed + $failed)
                
                if ($failed -gt 0) {
                    Write-Host "FAILED" -ForegroundColor Red -NoNewline
                } else {
                    Write-Host "PASSED" -ForegroundColor Green -NoNewline
                }

                Write-Host " - Total: $total, Passed: $passed, Failed: $failed"
            }
            catch {
                Write-Verbose "Could not parse test summary: $($summary.Name) - $_"
            }
        }
    } else {
        Write-Host "No test results found" -ForegroundColor Yellow
    }
    Write-Host ""
}

function Show-RecentLogs {
    param([int]$Lines = 20)

    Write-Host "RECENT LOGS" -ForegroundColor Yellow
    Write-Host ("-" * 40) -ForegroundColor Gray

    $logPath = Join-Path $ProjectPath "logs/aitherzero.log"

    if (Test-Path $logPath) {
        $logs = Get-Content $logPath -Tail $Lines -ErrorAction SilentlyContinue
        foreach ($log in $logs) {
            if ($log -match '\[ERROR') {
                Write-Host $log -ForegroundColor Red
            } elseif ($log -match '\[WARNING') {
                Write-Host $log -ForegroundColor Yellow
            } elseif ($log -match '\[DEBUG') {
                Write-Host $log -ForegroundColor Gray
            } else {
                Write-Host $log
            }
        }
    } else {
        Write-Host "Log file not found at: $logPath" -ForegroundColor Yellow
        Write-Host "Creating log file..." -ForegroundColor Gray

        # Initialize logging to create the file
        if (Get-Command Initialize-Logging -ErrorAction SilentlyContinue) {
            if ($PSCmdlet.ShouldProcess("logging system", "Initialize logging")) {
                Initialize-Logging
                Write-CustomLog -Message "Dashboard initialized logging system" -Level Information
            }
        }
    }
    Write-Host ""
}

function Show-ModuleStatus {
    Write-Host "MODULE STATUS" -ForegroundColor Yellow
    Write-Host ("-" * 40) -ForegroundColor Gray

    $domains = Get-ChildItem -Path (Join-Path $ProjectPath "aithercore") -Directory -ErrorAction SilentlyContinue

    foreach ($domain in $domains) {
        $modules = Get-ChildItem -Path $domain.FullName -Filter "*.psm1" -ErrorAction SilentlyContinue
        $hasReadme = Test-Path (Join-Path $domain.FullName "README.md")

        Write-Host "$($domain.Name): " -NoNewline
        Write-Host "$(@($modules).Count) modules" -ForegroundColor Green -NoNewline

        if ($hasReadme) {
            Write-Host " ✓" -ForegroundColor Green -NoNewline
        } else {
            Write-Host " (no README)" -ForegroundColor Yellow -NoNewline
        }
        Write-Host ""
    }
    Write-Host ""
}

function Show-RecentActivity {
    Write-Host "RECENT ACTIVITY" -ForegroundColor Yellow
    Write-Host ("-" * 40) -ForegroundColor Gray

    # Get recent git commits
    $gitLog = git log --oneline -5 2>/dev/null
    if ($gitLog) {
        Write-Host "Recent Commits:" -ForegroundColor Cyan
        $gitLog | ForEach-Object { Write-Host "  $_" -ForegroundColor Gray }
    }

    # Get recently modified files
    Write-Host "`nRecently Modified:" -ForegroundColor Cyan
    $recentFiles = Get-ChildItem -Path $ProjectPath -Recurse -File -ErrorAction SilentlyContinue |
        Where-Object { $_.LastWriteTime -gt (Get-Date).AddHours(-24) -and $_.FullName -notlike "*\.git\*" } |
        Sort-Object LastWriteTime -Descending |
        Select-Object -First 5

    foreach ($file in $recentFiles) {
        $relativePath = $file.FullName.Replace($ProjectPath, '').TrimStart('\', '/')
        $timeAgo = [math]::Round(((Get-Date) - $file.LastWriteTime).TotalMinutes)
        Write-Host "  $relativePath ($timeAgo min ago)" -ForegroundColor Gray
    }
    Write-Host ""
}

# Main Dashboard Display
Show-Header

if ($ShowAll -or (!$ShowLogs -and !$ShowTests -and !$ShowMetrics)) {
    # Show everything by default
    $ShowMetrics = $true
    $ShowTests = $true
    $ShowLogs = $true
}

$col1Width = 60
# Handle non-interactive environments
$windowWidth = 120  # Default width
if ($Host.UI.RawUI -and $Host.UI.RawUI.WindowSize) {
    try { $windowWidth = $Host.UI.RawUI.WindowSize.Width } catch { }
}
$col2Width = $windowWidth - $col1Width - 2

# Two column layout (skip cursor position in non-interactive)
$cursorPos = $null
if ($Host.UI.RawUI -and $Host.UI.RawUI.CursorPosition) {
    try { $cursorPos = $Host.UI.RawUI.CursorPosition } catch { }
}

if ($ShowMetrics) {
    Show-ProjectMetrics
    Show-ModuleStatus
}

if ($ShowTests) {
    Show-TestResults
}

if ($ShowLogs) {
    Show-RecentLogs -Lines $LogTailLines
}

Show-RecentActivity

# Footer
# Handle non-interactive environments
$separatorWidth = 80  # Default width
if ($Host.UI.RawUI -and $Host.UI.RawUI.WindowSize) {
    try { $separatorWidth = $Host.UI.RawUI.WindowSize.Width } catch { }
}
Write-Host ("=" * $separatorWidth) -ForegroundColor Cyan
Write-Host "Commands: " -NoNewline -ForegroundColor Yellow
Write-Host "0510 " -NoNewline -ForegroundColor Cyan
Write-Host "(Generate Report) | " -NoNewline
Write-Host "0402 " -NoNewline -ForegroundColor Cyan
Write-Host "(Run Tests) | " -NoNewline
Write-Host "0404 " -NoNewline -ForegroundColor Cyan
Write-Host "(Analyze Code)" -NoNewline
Write-Host ""

if ($Follow) {
    Write-Host "Following logs... Press Ctrl+C to exit" -ForegroundColor Yellow
    $logPath = Join-Path $ProjectPath "logs/aitherzero.log"
    if (Test-Path $logPath) {
        Get-Content $logPath -Wait -Tail 1
    }
}