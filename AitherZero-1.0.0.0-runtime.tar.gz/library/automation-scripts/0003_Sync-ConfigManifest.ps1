#Requires -Version 7.0
<#
.SYNOPSIS
    Synchronize config.psd1 with actual automation scripts
.DESCRIPTION
    Automatically discovers automation scripts in the automation-scripts directory
    and compares them with the scripts listed in config.psd1 manifest.
    
    Reports missing scripts and optionally updates config.psd1 with discovered scripts.
    Helps keep configuration in sync when new automation scripts are added.
    
    Exit Codes:
    0 - All scripts are registered or updated successfully
    1 - Missing scripts found (when not in Fix mode)
    2 - Execution error

.PARAMETER Fix
    Automatically add missing scripts to config.psd1
.PARAMETER DryRun
    Show what would be changed without making changes
.PARAMETER Verbose
    Show detailed information about the sync process
.EXAMPLE
    ./automation-scripts/0003_Sync-ConfigManifest.ps1
    Check for missing scripts in config.psd1
.EXAMPLE
    ./automation-scripts/0003_Sync-ConfigManifest.ps1 -Fix
    Automatically add missing scripts to config.psd1
.EXAMPLE
    ./automation-scripts/0003_Sync-ConfigManifest.ps1 -DryRun
    Preview what would be changed
.NOTES
    Stage: Environment Setup
    Order: 0003
    Dependencies: None
    Tags: configuration, maintenance, automation
#>

[CmdletBinding()]
param(
    [switch]$Fix,
    [switch]$DryRun
)

$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest

# Script metadata
$scriptMetadata = @{
    Stage = 'Environment'
    Order = '0003'
    Name = 'Sync-ConfigManifest'
    Description = 'Synchronize config.psd1 with automation scripts'
    Tags = @('configuration', 'maintenance', 'automation')
}

# Paths
$projectRoot = Split-Path (Split-Path $PSScriptRoot -Parent) -Parent
$configPath = Join-Path $projectRoot "config.psd1"
$scriptsPath = Join-Path $projectRoot "library/automation-scripts"

function Write-SyncLog {
    param(
        [string]$Message,
        [ValidateSet('Info', 'Success', 'Warning', 'Error')]
        [string]$Level = 'Info'
    )
    
    $color = switch ($Level) {
        'Error' { 'Red' }
        'Warning' { 'Yellow' }
        'Success' { 'Green' }
        default { 'Cyan' }
    }
    
    $icon = switch ($Level) {
        'Error' { '❌' }
        'Warning' { '⚠️' }
        'Success' { '✅' }
        default { 'ℹ️' }
    }
    
    Write-Host "$icon $Message" -ForegroundColor $color
}

# Discover all automation scripts
Write-SyncLog "Discovering automation scripts..." -Level Info

$discoveredScripts = Get-ChildItem -Path $scriptsPath -Filter "*.ps1" -ErrorAction SilentlyContinue |
    Where-Object { $_.Name -match '^\d{4}_' } |
    ForEach-Object {
        $number = $_.Name.Substring(0, 4)
        @{
            Number = $number
            Name = $_.Name
            Path = $_.FullName
        }
    } |
    Sort-Object { [int]$_.Number }

Write-SyncLog "Found $($discoveredScripts.Count) automation scripts" -Level Success

# Check for duplicate script numbers (CRITICAL)
Write-SyncLog "Checking for duplicate script numbers..." -Level Info
$duplicateNumbers = $discoveredScripts | 
    Group-Object Number | 
    Where-Object { $_.Count -gt 1 }

if ($duplicateNumbers) {
    Write-Host ""
    Write-SyncLog "CRITICAL: Duplicate script numbers detected!" -Level Error
    Write-Host ""
    Write-Host "╔══════════════════════════════════════════════════════════════╗" -ForegroundColor Red
    Write-Host "║            DUPLICATE SCRIPT NUMBERS FOUND                    ║" -ForegroundColor Red
    Write-Host "╚══════════════════════════════════════════════════════════════╝" -ForegroundColor Red
    Write-Host ""
    
    foreach ($dup in $duplicateNumbers) {
        Write-Host "Script Number: $($dup.Name) (found $($dup.Count) times)" -ForegroundColor Red
        foreach ($script in $dup.Group) {
            Write-Host "  • $($script.Name)" -ForegroundColor Yellow
        }
        Write-Host ""
    }
    
    Write-Host "💥 FAILURE: Duplicate script numbers are not allowed!" -ForegroundColor Red
    Write-Host ""
    Write-Host "Each automation script must have a unique number." -ForegroundColor White
    Write-Host "Please rename one of the duplicate scripts to use an available number." -ForegroundColor White
    Write-Host ""
    exit 2
}

Write-SyncLog "No duplicate script numbers found" -Level Success

# Load config.psd1
Write-SyncLog "Loading config.psd1..." -Level Info

if (-not (Test-Path $configPath)) {
    Write-SyncLog "config.psd1 not found at: $configPath" -Level Error
    exit 2
}

try {
    # Use scriptblock evaluation instead of Import-PowerShellDataFile
    # because config.psd1 contains PowerShell expressions ($true/$false) that
    # Import-PowerShellDataFile treats as "dynamic expressions"
    $content = Get-Content -Path $configPath -Raw
    $scriptBlock = [scriptblock]::Create($content)
    $config = & $scriptBlock
    
    if (-not $config -or $config -isnot [hashtable]) {
        throw "Config file did not return a valid hashtable"
    }
} catch {
    Write-SyncLog "Failed to load config.psd1: $($_.Exception.Message)" -Level Error
    exit 2
}

# Extract all script numbers from config
$registeredScripts = @{}
$config.Manifest.FeatureDependencies.GetEnumerator() | ForEach-Object {
    $category = $_.Key
    $_.Value.GetEnumerator() | ForEach-Object {
        $feature = $_.Key
        $featureData = $_.Value
        if ($featureData -is [hashtable] -and $featureData.ContainsKey('Scripts')) {
            $featureData.Scripts | ForEach-Object {
                $scriptNum = $_
                if (-not $registeredScripts.ContainsKey($scriptNum)) {
                    $registeredScripts[$scriptNum] = @()
                }
                $registeredScripts[$scriptNum] += "$category.$feature"
            }
        }
    }
}

Write-SyncLog "Found $($registeredScripts.Count) scripts registered in config.psd1" -Level Success

# Compare discovered vs registered
$missingScripts = @()
foreach ($script in $discoveredScripts) {
    if (-not $registeredScripts.ContainsKey($script.Number)) {
        $missingScripts += $script
    }
}

# Report results
Write-Host ""
Write-Host "╔══════════════════════════════════════════════════════════════╗" -ForegroundColor Cyan
Write-Host "║                  Config Sync Results                         ║" -ForegroundColor Cyan
Write-Host "╚══════════════════════════════════════════════════════════════╝" -ForegroundColor Cyan
Write-Host ""

Write-Host "Discovered Scripts: $($discoveredScripts.Count)" -ForegroundColor White
Write-Host "Registered Scripts: $($registeredScripts.Count)" -ForegroundColor White
Write-Host "Missing Scripts: $($missingScripts.Count)" -ForegroundColor $(if ($missingScripts.Count -gt 0) { 'Yellow' } else { 'Green' })
Write-Host ""

if ($missingScripts.Count -gt 0) {
    Write-SyncLog "Missing scripts found:" -Level Warning
    Write-Host ""
    
    # Group by range
    $grouped = $missingScripts | Group-Object { 
        $num = [int]$_.Number
        switch ($num) {
            { $_ -lt 100 } { '0000-0099' }
            { $_ -lt 200 } { '0100-0199' }
            { $_ -lt 300 } { '0200-0299' }
            { $_ -lt 400 } { '0300-0399' }
            { $_ -lt 500 } { '0400-0499' }
            { $_ -lt 600 } { '0500-0599' }
            { $_ -lt 700 } { '0600-0699' }
            { $_ -lt 800 } { '0700-0799' }
            { $_ -lt 900 } { '0800-0899' }
            { $_ -lt 1000 } { '0900-0999' }
            default { '9000-9999' }
        }
    }
    
    foreach ($group in $grouped) {
        Write-Host "  $($group.Name):" -ForegroundColor Cyan
        foreach ($script in $group.Group) {
            Write-Host "    • $($script.Number) - $($script.Name)" -ForegroundColor Yellow
        }
        Write-Host ""
    }
    
    Write-Host "💡 Suggested Actions:" -ForegroundColor Cyan
    Write-Host ""
    Write-Host "1. Review each missing script and determine the appropriate category" -ForegroundColor White
    Write-Host "2. Add script numbers to config.psd1 under Manifest.FeatureDependencies" -ForegroundColor White
    Write-Host "3. Update descriptions to reflect new scripts" -ForegroundColor White
    Write-Host ""
    Write-Host "Example sections to update:" -ForegroundColor Cyan
    Write-Host "  - Maintenance.Environment (0000-0099)" -ForegroundColor Gray
    Write-Host "  - Infrastructure (0100-0199)" -ForegroundColor Gray
    Write-Host "  - Development (0200-0299)" -ForegroundColor Gray
    Write-Host "  - Testing (0400-0499)" -ForegroundColor Gray
    Write-Host "  - Reporting (0500-0599)" -ForegroundColor Gray
    Write-Host "  - Git / AIAgents (0700-0799)" -ForegroundColor Gray
    Write-Host "  - IssueManagement (0800-0899)" -ForegroundColor Gray
    Write-Host ""
    
    if ($Fix) {
        Write-SyncLog "Fix mode not yet implemented - manual updates required" -Level Warning
        Write-Host "Manual editing of config.psd1 is recommended to ensure proper categorization" -ForegroundColor Yellow
    } elseif ($DryRun) {
        Write-SyncLog "Dry run complete - no changes made" -Level Info
    }
    
    exit 1
} else {
    Write-SyncLog "All automation scripts are registered in config.psd1!" -Level Success
}

# Check for duplicate script number references in config.psd1
Write-Host ""
Write-SyncLog "Checking config.psd1 for duplicate references..." -Level Info

$configDuplicates = $registeredScripts.GetEnumerator() | Where-Object { $_.Value.Count -gt 1 }
if ($configDuplicates) {
    Write-Host ""
    Write-SyncLog "CRITICAL: Duplicate script number references in config.psd1!" -Level Error
    Write-Host ""
    Write-Host "╔══════════════════════════════════════════════════════════════╗" -ForegroundColor Red
    Write-Host "║        DUPLICATE REFERENCES IN CONFIG.PSD1 FOUND            ║" -ForegroundColor Red
    Write-Host "╚══════════════════════════════════════════════════════════════╝" -ForegroundColor Red
    Write-Host ""
    
    foreach ($dup in $configDuplicates) {
        Write-Host "Script Number: $($dup.Key)" -ForegroundColor Red
        foreach ($location in $dup.Value) {
            Write-Host "  • Referenced in: $location" -ForegroundColor Yellow
        }
        Write-Host ""
    }
    
    Write-Host "💥 FAILURE: Duplicate references will break script execution!" -ForegroundColor Red
    Write-Host ""
    Write-Host "Each script number can only be referenced ONCE in config.psd1." -ForegroundColor White
    Write-Host "Multiple references cause ambiguity and execution failures." -ForegroundColor White
    Write-Host ""
    Write-Host "🔧 Action Required:" -ForegroundColor Red
    Write-Host "  1. Review the duplicate references listed above" -ForegroundColor White
    Write-Host "  2. Determine which feature should own each script" -ForegroundColor White
    Write-Host "  3. Remove duplicate entries from config.psd1" -ForegroundColor White
    Write-Host "  4. Re-run this validation script" -ForegroundColor White
    Write-Host ""
    exit 2
}

Write-Host ""
Write-Host "✅ Configuration is in sync" -ForegroundColor Green
exit 0
