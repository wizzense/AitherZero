#Requires -Version 7.0

<#
.SYNOPSIS
    Tests the development environment setup for completeness.

.DESCRIPTION
    This function validates that the development environment is properly configured
    and all required components are available.

.PARAMETER Detailed
    Return detailed validation results for each component.

.EXAMPLE
    Test-DevelopmentSetup

.EXAMPLE
    Test-DevelopmentSetup -Detailed
#>

function Test-DevelopmentSetup {
    [CmdletBinding()]
    param(
        [switch]$Detailed
    )
    
    begin {
        $validationResults = @()
        
        function Add-ValidationResult {
            param($Test, $Status, $Message)
            $validationResults += @{
                Test = $Test
                Status = $Status
                Message = $Message
            }
        }
    }
    
    process {
        try {
            # Test PowerShell Version
            $psVersion = $PSVersionTable.PSVersion
            $psStatus = if ($psVersion.Major -ge 7) { "PASS" } else { "FAIL" }
            Add-ValidationResult "PowerShell Version" $psStatus "PowerShell $psVersion"
            
            # Test Project Root
            $projectRootStatus = if ($env:PROJECT_ROOT -and (Test-Path $env:PROJECT_ROOT)) { "PASS" } else { "FAIL" }
            $projectRootMessage = if ($env:PROJECT_ROOT) { $env:PROJECT_ROOT } else { "Not Set" }
            Add-ValidationResult "Project Root" $projectRootStatus $projectRootMessage
            
            # Test Module Path
            $modulePathStatus = if ($env:PWSH_MODULES_PATH -and (Test-Path $env:PWSH_MODULES_PATH)) { "PASS" } else { "WARN" }
            $modulePathMessage = if ($env:PWSH_MODULES_PATH) { $env:PWSH_MODULES_PATH } else { "Not Set" }
            Add-ValidationResult "Module Path" $modulePathStatus $modulePathMessage
            
            # Test Git Availability
            $gitAvailable = Get-Command git -ErrorAction SilentlyContinue
            $gitStatus = if ($gitAvailable) { "PASS" } else { "FAIL" }
            $gitMessage = if ($gitAvailable) { "Git available" } else { "Git not found" }
            Add-ValidationResult "Git" $gitStatus $gitMessage
            
            # Test Core Modules
            $coreModules = @("Logging", "LabRunner", "DevEnvironment", "PatchManager")
            foreach ($module in $coreModules) {
                try {
                    $moduleAvailable = Get-Module -ListAvailable -Name $module -ErrorAction SilentlyContinue
                    if (-not $moduleAvailable -and $env:PROJECT_ROOT) {
                        $modulePath = Join-Path $env:PROJECT_ROOT "aither-core/modules/$module"
                        $moduleAvailable = Test-Path $modulePath
                    }
                    
                    $moduleStatus = if ($moduleAvailable) { "PASS" } else { "WARN" }
                    $moduleMessage = if ($moduleAvailable) { "Available" } else { "Not Found" }
                    Add-ValidationResult "Module: $module" $moduleStatus $moduleMessage
                } catch {
                    Add-ValidationResult "Module: $module" "ERROR" $_.Exception.Message
                }
            }
            
            if ($Detailed) {
                return $validationResults
            } else {
                # Return summary
                $passed = ($validationResults | Where-Object { $_.Status -eq "PASS" }).Count
                $total = $validationResults.Count
                $failed = ($validationResults | Where-Object { $_.Status -eq "FAIL" }).Count
                
                Write-CustomLog "Development Environment Status: $passed/$total tests passed" -Level INFO
                if ($failed -gt 0) {
                    Write-CustomLog "$failed critical issues found" -Level WARN
                    return $false
                } else {
                    Write-CustomLog "Development environment is properly configured" -Level SUCCESS
                    return $true
                }
            }
            
        } catch {
            Write-CustomLog "Error testing development setup: $($_.Exception.Message)" -Level ERROR
            if ($Detailed) {
                Add-ValidationResult "Test Execution" "ERROR" $_.Exception.Message
                return $validationResults
            } else {
                return $false
            }
        }
    }
}
